# main.py
import os
import re
import json
import asyncio
from typing import Optional

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

import requests

from orders import (
    MexcError,
    get_account_balances,
    get_price,
    preview_market_buy,
    place_market_buy,
)

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN") or os.getenv("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("Не задан BOT_TOKEN (env).")

ALLOWED_IDS = [x.strip() for x in (os.getenv("ALLOWED_IDS", "")).split(",") if x.strip()]
DEFAULT_BUDGET = float(os.getenv("DEFAULT_BUDGET", "25"))
LIVE_ARM = os.getenv("LIVE_ARM", "0").strip() == "1"

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()


def is_allowed(user_id: int) -> bool:
    if not ALLOWED_IDS:
        return True
    return str(user_id) in ALLOWED_IDS


def fmt_money(v: Optional[float]) -> str:
    if v is None:
        return "n/a"
    if v >= 100:
        return f"{v:,.2f}".replace(",", " ")
    if v >= 1:
        return f"{v:.2f}"
    return f"{v:.8f}".rstrip("0").rstrip(".")


def build_portfolio_text() -> str:
    try:
        balances = get_account_balances()  # требует API ключи
    except MexcError as e:
        return f"Ошибка при получении портфеля: <code>{str(e)}</code>"

    # Разделим стейбл/крипто
    usdt = float(balances.get("USDT", 0))
    lines = ["<b>📊 Портфель</b>", ""]
    total_usdt = usdt

    # Соберём список не-USDT
    non_stables = []
    for asset, qty in balances.items():
        if asset == "USDT":
            continue
        symbol = f"{asset}USDT"
        try:
            price = get_price(symbol)
            worth = qty * price
            total_usdt += worth
            non_stables.append((asset, qty, price, worth))
        except Exception:
            non_stables.append((asset, qty, None, None))

    # Сортировка по стоимости
    non_stables.sort(key=lambda x: (x[3] or 0), reverse=True)

    # Отрисовка
    for asset, qty, price, worth in non_stables:
        if price is None or worth is None:
            lines.append(f"• {asset}: {fmt_money(qty)}\n"
                         f"   Цена: n/a  |  Стоимость: n/a\n"
                         f"   Вход: n/a  |  P/L: n/a\n")
        else:
            lines.append(f"• {asset}: {fmt_money(qty)}\n"
                         f"   Цена: {fmt_money(price)}  |  Стоимость: {fmt_money(worth)} USDT\n"
                         f"   Вход: n/a  |  P/L: n/a\n")

    lines.append(f"• USDT: {fmt_money(usdt)}")
    lines.append("")
    lines.append(f"💰 Итоговая стоимость: <b>{fmt_money(total_usdt)} USDT</b>")
    return "\n".join(lines)


# ============ Команды ============

@dp.message(F.text == "/start")
async def cmd_start(m: Message):
    if not is_allowed(m.from_user.id):
        return await m.answer("⛔️ Доступ запрещён.")
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Баланс / Портфель", callback_data="menu:portfolio")],
        [InlineKeyboardButton(text="Рынок", callback_data="menu:market")],
        [InlineKeyboardButton(text="Сигналы", callback_data="menu:signals")],
        [InlineKeyboardButton(text="AI Обзор", callback_data="menu:ai")],
        [InlineKeyboardButton(text="Настройки", callback_data="menu:settings")],
    ])
    await m.answer("Бот подключен. Выберите действие:", reply_markup=kb)


@dp.callback_query(F.data == "menu:portfolio")
async def cb_portfolio(cq: CallbackQuery):
    if not is_allowed(cq.from_user.id):
        return await cq.answer("⛔️")
    await cq.message.edit_text("Загружаю данные…")
    text = build_portfolio_text()
    await cq.message.edit_text(text)


@dp.callback_query(F.data == "menu:market")
async def cb_market(cq: CallbackQuery):
    if not is_allowed(cq.from_user.id):
        return await cq.answer("⛔️")
    await cq.message.edit_text("Эта секция без изменений. (работает как у тебя)")

@dp.callback_query(F.data == "menu:signals")
async def cb_signals(cq: CallbackQuery):
    if not is_allowed(cq.from_user.id):
        return await cq.answer("⛔️")
    await cq.message.edit_text("Сканирую рынок…")
    await asyncio.sleep(0.5)
    await cq.message.edit_text("Сильных сигналов не найдено.")


# ============ AI Обзор ============

AI_SAMPLE_TEXT = """1) Выводы по рынку:
- Смешанная динамика: активы-лидеры растут, часть падает.
- Объёмы по мейджорам высокие.

2) Предложения по сделкам

• Сделка 1: ALTHEAUSDT | вход 0.6061 | стоп 0.581856 | тейк 0.642466
  Обоснование: Лидер роста 24ч с повышенным интересом, пробой импульса.
• Сделка 2: ETHUSDT | вход 4213.35 | стоп 4150.14975 | тейк 4297.617
  Обоснование: Сильный объём — вероятно продолжение движения.
"""

trade_line_re = re.compile(
    r"Сделка\s+\d+:\s*([A-Z0-9]+)\s*\|\s*вход\s*([\d\.eE-]+)\s*\|\s*стоп\s*([\d\.eE-]+)\s*\|\s*тейк\s*([\d\.eE-]+)",
    re.IGNORECASE
)

def parse_trades_from_text(text: str):
    trades = []
    for m in trade_line_re.finditer(text):
        symbol = m.group(1).upper()
        entry = float(m.group(2))
        sl = float(m.group(3))
        tp = float(m.group(4))
        trades.append({"symbol": symbol, "entry": entry, "sl": sl, "tp": tp})
    return trades


@dp.callback_query(F.data == "menu:ai")
async def cb_ai(cq: CallbackQuery):
    if not is_allowed(cq.from_user.id):
        return await cq.answer("⛔️")

    await cq.message.edit_text("Готовлю AI-обзор…")
    # Здесь ты можешь подставить свой реальный AI текст.
    ai_text = AI_SAMPLE_TEXT

    trades = parse_trades_from_text(ai_text)

    # Сначала показываем сам текст
    await cq.message.edit_text(ai_text)

    # А затем отправляем под ним кнопки на сделки
    if trades:
        rows = []
        for t in trades:
            # кнопка "Предпросмотр"
            cb = f"ai:preview:{t['symbol']}:{t['entry']}:{t['sl']}:{t['tp']}"
            rows.append([InlineKeyboardButton(text=f"Сделка {t['symbol']} — предпросмотр", callback_data=cb)])
        kb = InlineKeyboardMarkup(inline_keyboard=rows)
        await cq.message.answer("Выбери сделку для предпросмотра:", reply_markup=kb)
    else:
        await cq.message.answer("Сделки в тексте не найдены.")


@dp.callback_query(F.data.startswith("ai:preview:"))
async def cb_ai_preview(cq: CallbackQuery):
    if not is_allowed(cq.from_user.id):
        return await cq.answer("⛔️")

    try:
        _, _, symbol, entry, sl, tp = cq.data.split(":")
        entry = float(entry)
        sl = float(sl)
        tp = float(tp)

        preview = preview_market_buy(symbol, DEFAULT_BUDGET, sl=sl, tp=tp)

        text = (
            f"<b>Предпросмотр</b>\n"
            f"Символ: <code>{symbol}</code>\n"
            f"Сумма: {fmt_money(DEFAULT_BUDGET)} USDT\n"
            f"Цена~: {fmt_money(preview['price'])}\n"
            f"Кол-во~: {fmt_money(preview['qty'])}\n"
            f"Стоп: {fmt_money(sl)}  |  Тейк: {fmt_money(tp)}\n\n"
            f"Подтвердить покупку?"
        )
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Купить", callback_data=f"ai:confirm:{symbol}:{sl}:{tp}"),
                InlineKeyboardButton(text="❌ Отмена", callback_data="ai:cancel"),
            ]
        ])
        await cq.message.answer(text, reply_markup=kb)
    except Exception as e:
        await cq.message.answer(f"⚠️ Ошибка предпросмотра: <code>{str(e)}</code>")


@dp.callback_query(F.data == "ai:cancel")
async def cb_ai_cancel(cq: CallbackQuery):
    if not is_allowed(cq.from_user.id):
        return await cq.answer("⛔️")
    await cq.message.edit_text("Отменено.")


@dp.callback_query(F.data.startswith("ai:confirm:"))
async def cb_ai_confirm(cq: CallbackQuery):
    if not is_allowed(cq.from_user.id):
        return await cq.answer("⛔️")
    try:
        _, _, symbol, sl, tp = cq.data.split(":")
        sl = float(sl)
        tp = float(tp)

        res = place_market_buy(symbol, DEFAULT_BUDGET, sl=sl, tp=tp)
        if res.get("status") == "DRY_RUN":
            text = (
                "🔎 <b>Демо-режим</b>: ордер не отправлен на биржу.\n\n"
                f"<code>{res}</code>"
            )
        else:
            text = "✅ Покупка выполнена.\n<code>" + json.dumps(res, ensure_ascii=False, indent=2) + "</code>"

        await cq.message.edit_text(text)
    except MexcError as me:
        await cq.message.edit_text(f"⚠️ Ошибка MEXC: <code>{str(me)}</code>")
    except Exception as e:
        await cq.message.edit_text(f"⚠️ Ошибка: <code>{str(e)}</code>")


# ============ Настройки ============

@dp.callback_query(F.data == "menu:settings")
async def cb_settings(cq: CallbackQuery):
    if not is_allowed(cq.from_user.id):
        return await cq.answer("⛔️")
    text = (
        "<b>Настройки портфеля</b>:\n"
        "Задать вход вручную: <code>set entry SYMBOL PRICE</code>\n"
        "Например: <code>set entry BTCUSDT 111000</code>\n\n"
        f"Режим сделок: <b>{'LIVE' if LIVE_ARM else 'DEMO'}</b>\n"
        f"Бюджет по умолчанию: <b>{fmt_money(DEFAULT_BUDGET)} USDT</b>\n"
    )
    await cq.message.edit_text(text)


# Текстовые команды на всякий (например: "set entry BTCUSDT 111000")
@dp.message(F.text.regexp(r"^set\s+entry\s+[A-Za-z0-9]+USDT\s+[\d\.eE+-]+$"))
async def cmd_set_entry(m: Message):
    if not is_allowed(m.from_user.id):
        return await m.answer("⛔️ Доступ запрещён.")
    await m.answer("OK (дамп настроек/хранилища входов ты можешь дописать в свой модуль).")


# Прямая команда “Баланс”
@dp.message(F.text.lower() == "баланс")
async def cmd_balance(m: Message):
    if not is_allowed(m.from_user.id):
        return await m.answer("⛔️ Доступ запрещён.")
    await m.answer("Загружаю данные…")
    text = build_portfolio_text()
    await m.answer(text)


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
